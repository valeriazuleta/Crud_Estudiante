# Definimos tres diccionarios para almacenar estudiantes, materias y notas.
# Cada uno tendrá un código único como clave y los datos como valor.
estudiantes = []

materia=[]

notas = []

# Definimos una función para mostrar los menús y manejar la entrada del usuario.
def menu_principal():
    while True:
        print("\n--- MENÚ PRINCIPAL ---")
        print("1. Ingresar estudiante")
        print("2. Ingresar materias")
        print("3. Ingresar notas")
        print("4. Estadística")
        print("5. Salir")
        
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            menu_estudiantes()
        elif opcion == "2":
            menu_materias()
        elif opcion == "3":
            menu_notas()
        elif opcion == "4":
            menu_estadisticas()
        elif opcion == "5":
            break
        else:
            print("Opción inválida, por favor intente de nuevo.")


def menu_estudiantes():
    while True:
        print("\n--- MENÚ ESTUDIANTES ---")
        print("1. Ingresar estudiante")
        print("2. Ingresar código de estudiante")
        print("3. Listar estudiantes")
        print("4. Actualizar estudiante")
        print("5. Eliminar estudiante")
        print("6. Buscar estudiante")
        print("7. Volver al menú principal")
        
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            nombre = input("Ingrese el nombre del estudiante: ")
            codigo = input("Ingrese el código del estudiante: ")
            if codigo in estudiantes:
                print("El código de estudiante ya existe, por favor intente de nuevo.")
            else:
                estudiantes[codigo] = {"nombre": nombre}
                print("Estudiante agregado exitosamente.")
        elif opcion == "2":
            codigo = input("Ingrese el código del estudiante: ")
            if codigo in estudiantes:
                print("Nombre del estudiante:", estudiantes[codigo]["nombre"])
            else:
                print("El código de estudiante no existe.")
        elif opcion == "3":
            print("Lista de estudiantes:")
            for codigo, datos in estudiantes.items():
                print("Código:", codigo, "- Nombre:", datos["nombre"])
        elif opcion == "4":
            codigo = input("Ingrese el código del estudiante a actualizar: ")
            if codigo in estudiantes:
                nombre = input("Ingrese el nuevo nombre del estudiante: ")
                estudiantes[codigo]["nombre"] = nombre
                print("Estudiante actualizado exitosamente.")
            else:
                print("El código de estudiante no existe.")
        elif opcion == "5":
            codigo = input("Ingrese el código del estudiante a eliminar: ")
            if codigo in estudiantes:
                del estudiantes[codigo]
                print("Estudiante eliminado exitosamente.")
            else:
                print("El código de estudiante no existe.")
        elif opcion == "6":
            codigo = input("Ingrese el código del estudiante: ")
            if codigo in estudiantes:
                print("Código:", codigo, "- Nombre:", estudiantes[codigo]["nombre"])
            else:
                print("El código de estudiante no existe.")
        elif opcion == "7":
            break
        else:
            print("Opción inválida, por favor intente de nuevo.")


# Definimos tres diccionarios para almacenar estudiantes, materias y notas.
# Cada uno tendrá un código único como clave y los datos como valor.
estudiantes = []
materias = []
notas = []

# Definimos una función para mostrar los menús y manejar la entrada del usuario.
def menu_principal():
    while True:
        print("\n--- MENÚ PRINCIPAL ---")
        print("1. Ingresar estudiante")
        print("2. Ingresar materias")
        print("3. Ingresar notas")
        print("4. Estadística")
        print("5. Salir")
        
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            menu_estudiantes()
        elif opcion == "2":
            menu_materias()
        elif opcion == "3":
            menu_notas()
        elif opcion == "4":
            menu_estadisticas()
        elif opcion == "5":
            break
        else:
            print("Opción inválida, por favor intente de nuevo.")


def menu_estudiantes():
    while True:
        print("\n--- MENÚ ESTUDIANTES ---")
        print("1. Ingresar estudiante")
        print("2. Ingresar código de estudiante")
        print("3. Listar estudiantes")
        print("4. Actualizar estudiante")
        print("5. Eliminar estudiante")
        print("6. Buscar estudiante")
        print("7. Volver al menú principal")
        
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            nombre = input("Ingrese el nombre del estudiante: ")
            codigo = input("Ingrese el código del estudiante: ")
            if codigo in estudiantes:
                print("El código de estudiante ya existe, por favor intente de nuevo.")
            else:
                estudiantes[codigo] = {"nombre": nombre}
                print("Estudiante agregado exitosamente.")
        elif opcion == "2":
            codigo = input("Ingrese el código del estudiante: ")
            if codigo in estudiantes:
                print("Nombre del estudiante:", estudiantes[codigo]["nombre"])
            else:
                print("El código de estudiante no existe.")
        elif opcion == "3":
            print("Lista de estudiantes:")
            for codigo, datos in estudiantes.items():
                print("Código:", codigo, "- Nombre:", datos["nombre"])
        elif opcion == "4":
            codigo = input("Ingrese el código del estudiante a actualizar: ")
            if codigo in estudiantes:
                nombre = input("Ingrese el nuevo nombre del estudiante: ")
                estudiantes[codigo]["nombre"] = nombre
                print("Estudiante actualizado exitosamente.")
            else:
                print("El código de estudiante no existe.")
        elif opcion == "5":
            codigo = input("Ingrese el código del estudiante a eliminar: ")
            if codigo in estudiantes:
                del estudiantes[codigo]
                print("Estudiante eliminado exitosamente.")
            else:
                print("El código de estudiante no existe.")
        elif opcion == "6":
            codigo = input("Ingrese el código del estudiante: ")
            if codigo in estudiantes:
                print("Código:", codigo, "- Nombre:", estudiantes[codigo]["nombre"])
            else:
                print("El código de estudiante no existe.")
        elif opcion == "7":
            break
        else:
            print("Opción inválida, por favor intente de nuevo.")


def menu_materias():
    while True:
        print("\n--- MENÚ MATERIAS ---")
        print("1. Ingresar materia")
        print("2. Ingresar código de materia")
        print("3. Buscar materia")
        print("4. Actualizar materia")
        print("5. Eliminar materia")
        print("6. Volver al menú principal")
        
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            materia = input("Ingrese el nombre de la materia: ")
            codigo = input("Ingrese el código de la materia: ")
            if codigo in materias:
                print("El código de materia ya existe, por favor intente de nuevo.")
            else:
                materias[codigo] = {"nombre": materia}
                print("Materia agregada exitosamente.")
        elif opcion == "2":
            codigo = input("Ingrese el código de la materia: ")
            if codigo in materias:
                print("Nombre de la materia:", materias[codigo]["nombre"])
            else:
                print("El código de materia no existe.")
        elif opcion == "3":
            codigo = input("Ingrese el código de la materia: ")
            if codigo in materias:
                print("Código:", codigo, "- Nombre:", materias[codigo]["nombre"])
            else:
                print("El código de materia no existe.")
        elif opcion == "4":
            codigo = input("Ingrese el código de la materia a actualizar: ")
            if codigo in materias:
                materia = input("Ingrese el nuevo nombre de la materia: ")
                materias[codigo]["nombre"] = materia
                print("Materia actualizada exitosamente.")
            else:
                print("El código de materia no existe.")
        elif opcion == "5":
            codigo = input("Ingrese el código de la materia a eliminar: ")
            if codigo in materias:
                del materias[codigo]
                print("Materia eliminada exitosamente.")
            else:
                print("El código de materia no existe.")
        elif opcion == "6":
            break
        else:
            print("Opción inválida, por favor intente de nuevo.")


def menu_notas():
    while True:
        print("\n--- MENÚ NOTAS ---")
        print("1. Ingresar código de estudiante")
        print("2. Ingresar código de materia")
        print("3. Agregar nota")
        print("4. Eliminar nota")
        print("5. Volver al menú principal")
        
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            codigo_estudiante = input("Ingrese el código del estudiante: ")
            if codigo_estudiante in estudiantes:
                print("Nombre del estudiante:", estudiantes[codigo_estudiante]["nombre"])
            else:
                print("El código de estudiante no existe.")
        elif opcion == "2":
            codigo_materia = input("Ingrese el código de la materia: ")
            if codigo_materia in materias:
                print("Nombre de la materia:", materias[codigo_materia]["nombre"])
            else:
                print("El código de materia no existe.")
        elif opcion == "3":
            codigo_estudiante = input("Ingrese el código del estudiante: ")
            codigo_materia = input("Ingrese el código de la materia: ")
            nota = float(input("Ingrese la nota: "))
            clave = codigo_estudiante + "-" + codigo_materia
            notas[clave] = nota
            print("Nota agregada exitosamente.")
            if codigo_estudiante and codigo_materia in clave:
                print("ese estudiante tiene una nota agredada")
            
        elif opcion == "4":
            codigo_estudiante = input("Ingrese el código del estudiante: ")
            codigo_materia = input("Ingrese el código de la materia: ")
            clave = codigo_estudiante + "-" + codigo_materia
            if clave in notas:
                del notas[clave]
                print("Nota eliminada exitosamente.")
            else:
                print("No se encontró la nota.")
        elif opcion == "5":
            break
        else:
            print("Opción inválida, por favor intente de nuevo.")


def menu_estadisticas():
    while True:
        print("\n--- MENÚ ESTADÍSTICAS ---")
        print("1. Mostrar nota de un estudiante por código")
        print("2. Mostrar promedio por materia")
        print("3. Mostrar estudiante con la nota más alta por materia")
        print("4. Mostrar estudiante con la nota más baja por materia")
        print("5. Volver al menú principal")
        
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            codigo_estudiante = input("Ingrese el código del estudiante: ")
            promedio = 0
            total_notas = 0
            total_materias = 0
            for clave, nota in notas.items():
                partes = clave.split("-")
                if partes[0] == codigo_estudiante:
                    total_notas += nota
                    total_materias += 1
            if total_materias == 0:
                print("No se encontraron notas para el estudiante.")
            else:
                promedio = total_notas / total_materias
                print("Promedio del estudiante", codigo_estudiante, ":", promedio)
        elif opcion == "2":
            for codigo, materia in materias.items():
                promedio = 0
                total_notas = 0
                total_estudiantes = 0
                for clave, nota in notas.items():
                    partes = clave.split("-")
                    if partes[1] == codigo:
                        total_notas += nota
                        total_estudiantes += 1
                if total_estudiantes > 0:
                    promedio = total_notas / total_estudiantes
                print("Promedio de", materia["nombre"], ":", promedio)
        elif opcion == "3":
            for codigo, materia in materias.items():
                nota_maxima = 0
                estudiante_maximo = ""
                for clave, nota in notas.items():
                    partes = clave.split("-")
                    if partes[1] == codigo and nota > nota_maxima:
                        nota_maxima = nota
                        estudiante_maximo = partes[0]
                if estudiante_maximo != "":
                    print("Materia:", materia["nombre"], "- Estudiante con la nota más alta:", estudiantes[estudiante_maximo]["nombre"], "-", nota_maxima)
        elif opcion == "4":
            for codigo, materia in materias.items():
                nota_minima = 5
                estudiante_minimo = ""
                for clave, nota in notas.items():
                    partes = clave.split("-")
                    if partes[1] == codigo and nota < nota_minima:
                        nota_minima = nota
                        estudiante_minimo = partes[0]
                if estudiante_minimo != "":
                    print("Materia:", materia["nombre"], "- Estudiante con la nota más baja:", estudiantes[estudiante_minimo]["nombre"], "-", nota_minima)
        elif opcion == "5":
            break
        else:
            print("Opción inválida, por favor intente de nuevo.")


def main():
    while True:
        print("\n--- MENÚ PRINCIPAL ---")
        print("1. Ingresar estudiante")
        print("2. Ingresar materia")
        print("3. Ingresar nota")
        print("4. Estadísticas")
        print("5. Salir")

        opcion = input("Ingrese una opción: ")

        if opcion == "1":
            menu_estudiantes()
        elif opcion == "2":
            menu_materias()
        elif opcion == "3":
            menu_notas()
        elif opcion == "4":
            menu_estadisticas()
        elif opcion == "5":
            print("¡Hasta luego!")
            break
        else:
            print("Opción inválida, por favor intente de nuevo.")


if __name__ == "__main__":
    main()




