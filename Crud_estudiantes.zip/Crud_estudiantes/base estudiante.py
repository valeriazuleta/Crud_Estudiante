estudiantes = []
materias = []
notas = []

def menu_principal():
    print("=== Menú Principal ===")
    print("1. Agregar estudiante")
    print("2. Agregar materia")
    print("3. Agregar nota")
    print("4. Ver promedio de materias por estudiante")
    print("5. Ver nota mayor por estudiante")
    print("6. Ver nota menor por materia")
    print("7. listar estudiantes")
    print("0. Salir")

def menu_agregar_estudiante():
    print("=== Agregar Estudiante ===")
    codigo = int(input("Ingrese el código del estudiante: "))
    if codigo in estudiantes:
        print("El código de estudiante ya existe")
    else:
        nombre = input("Ingrese el nombre del estudiante: ")
        estudiantes.append(codigo)
        estudiantes.append(nombre)
        print("Estudiante agregado con éxito")

def menu_agregar_materia():
    print("=== Agregar Materia ===")
    codigo = int(input("Ingrese el código de la materia: "))
    if codigo in materias:
        print("El código de materia ya existe")
    else:
        nombre = input("Ingrese el nombre de la materia: ")
        materias.append(codigo)
        materias.append(nombre)
        print("Materia agregada con éxito")

def menu_agregar_nota():
    print("=== Agregar Nota ===")
    codigo_estudiante = int(input("Ingrese el código del estudiante: "))
    if codigo_estudiante not in estudiantes:
        print("El código de estudiante no existe")
    else:
        codigo_materia = int(input("Ingrese el código de la materia: "))
        if codigo_materia not in materias:
            print("El código de materia no existe")
        else:
            nota = float(input("Ingrese la nota del estudiante: "))
            estudiante_materia_index = -1
            for i in range(len(notas)):
                if notas[i][0] == codigo_estudiante and notas[i][1] == codigo_materia:
                    estudiante_materia_index = i
                    break
            if estudiante_materia_index != -1:
                print("El estudiante ya tiene una nota para esta materia")
            else:
                notas.append([codigo_estudiante, codigo_materia, nota])
                print("Nota agregada con éxito")

def menu_ver_promedio_materias():
    print("=== Ver Promedio de Materias por Estudiante ===")
    codigo_estudiante = int(input("Ingrese el código del estudiante: "))
    if codigo_estudiante not in estudiantes:
        print("El código de estudiante no existe")
    else:
        notas_estudiante = []
        for i in range(len(notas)):
            if notas[i][0] == codigo_estudiante:
                notas_estudiante.append(notas[i][2])
        if len(notas_estudiante) == 0:
            print("El estudiante no tiene notas registradas")
        else:
            promedio = sum(notas_estudiante) / len(notas_estudiante)
            nombre_estudiante_index = estudiantes.index(codigo_estudiante) + 1
            nombre_estudiante = estudiantes[nombre_estudiante_index]
            print(f"Promedio de notas del estudiante {nombre_estudiante}: {promedio:.2f}")

def menu_ver_nota_mayor():
    print("=== Ver Nota Mayor por Estudiante ===")
    codigo_estudiante = int(input("Ingrese el código del estudiante: "))
    if codigo_estudiante not in estudiantes:
        print("El código de estudiante no existe")
    else:
        notas_estudiante = []
        for i in range(len(notas)):
            if notas[i][0] == codigo_estudiante:
                notas_estudiante.append(notas[i])
        if len(notas_estudiante) == 0:
            print("El estudiante no tiene notas registradas")
        else:
            nota_mayor = max(notas_estudiante, key=lambda x: x[2])
            nombre_estudiante_index = estudiantes.index(codigo_estudiante) + 1
            nombre_estudiante = estudiantes[nombre_estudiante_index]
            nombre_materia_index = materias.index(nota_mayor[1]) + 1
            nombre_materia = materias[nombre_materia_index]
            print(f"Nota mayor del estudiante {nombre_estudiante} en la materia {nombre_materia}: {nota_mayor[2]}")

def menu_ver_nota_menor():
    print("=== Ver Nota Menor por Materia ===")
    codigo_materia = int(input("Ingrese el código de la materia: "))
    if codigo_materia not in materias:
        print("El código de materia no existe")
    else:
        notas_materia = []
        for i in range(len(notas)):
            if notas[i][1] == codigo_materia:
                notas_materia.append(notas[i])
        if len(notas_materia) == 0:
            print("No hay notas registradas para la materia")
        else:
            nota_menor = min(notas_materia, key=lambda x: x[2])
            nombre_materia_index = materias.index(codigo_materia) + 1
            nombre_materia = materias[nombre_materia_index]
            codigo_estudiante = nota_menor[0]
            nombre_estudiante_index = estudiantes.index(codigo_estudiante) + 1
            nombre_estudiante = estudiantes[nombre_estudiante_index]
            print(f"Nota menor en la materia {nombre_materia} del estudiante {nombre_estudiante}: {nota_menor[2]}")
def menu_listar_estudiantes():
    print("=== Listado de Estudiantes ===")
    if len(estudiantes) == 0:
        print("No hay estudiantes registrados")
    else:
        for i in range(0, len(estudiantes), 2):
            print(f"Código: {estudiantes[i]} - Nombre: {estudiantes[i+1]}")

while True:
    menu_principal()
    opcion = int(input("Ingrese una opción: "))
    if opcion == 0:
        print("Saliendo del programa")
        break
    elif opcion == 1:
        menu_agregar_estudiante()
    elif opcion == 2:
        menu_agregar_materia()
    elif opcion == 3:
        menu_agregar_nota()
    elif opcion == 4:
        menu_ver_promedio_materias()
    elif opcion == 5:
        menu_ver_nota_mayor()
    elif opcion == 6:
        menu_ver_nota_menor()
    elif opcion==7:
        menu_listar_estudiantes()
    else:
        print("Opción inválida")


